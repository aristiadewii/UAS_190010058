package com.example.filmpert10;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class MenuAdaptor extends RecyclerView.Adapter<MenuAdaptor.MenuViewHolder> {
    private Context context;
    private ArrayList<Film> menus;

    public MenuAdaptor(Context mcontext, ArrayList<Film> menufilm){
    context=mcontext;
    menus=menufilm;

    }

    @NonNull
    @Override
    public MenuViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(context).inflate(R.layout.item_menu,parent,false);

        return new MenuViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull MenuViewHolder holder, int position) {
            Film menubaru = menus.get(position);
            String gambarbaru = menubaru.getGambar();
            String negara = menubaru.getNegara();
            String nama = menubaru.getNama();

            holder.tvnamadata.setText(nama);
            holder.tvnegaradata.setText(negara);
        Glide
                .with(context)
                .load(gambarbaru)
                .centerCrop()
                .into(holder.imdata);
    }

    @Override
    public int getItemCount() {
        return menus.size();
    }

    public class MenuViewHolder extends RecyclerView.ViewHolder {
        public ImageView imdata;
        public TextView tvnegaradata;
        public TextView tvnamadata;

        public MenuViewHolder(@NonNull View itemView) {
            super(itemView);
            imdata=itemView.findViewById(R.id.img_film);
            tvnegaradata=itemView.findViewById(R.id.tv_negara);
            tvnamadata=itemView.findViewById(R.id.tv_nama);



        }
    }

}
