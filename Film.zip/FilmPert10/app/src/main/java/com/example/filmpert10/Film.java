package com.example.filmpert10;

public class Film {
    private String nama;
    private String negara;
    private String gambar;

    public Film(String datanama, String datanegara, String datagambar){
        nama = datanama;
        negara = datanegara;
        gambar = datagambar;
    }

    public String getNama() {
        return nama;
    }

    public String getNegara() {
        return negara;
    }

    public String getGambar() {
        return gambar;
    }
}
